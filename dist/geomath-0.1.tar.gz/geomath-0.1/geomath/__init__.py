"""
GeoMath - Analytical Geometry Module
Euclidean Geometry Library for Python Files
Originally written by: Vinicius Mesel and Eduardo Mendes
Last Modification: 18/04/2016 #vmesel
"""
